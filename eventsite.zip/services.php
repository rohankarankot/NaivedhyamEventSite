<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Our Services </title>
  <!-- MDB icon -->
 <?php include 'includes/links.php';
  $page = 'Services';?>
</head>
<body>

  <!-- Start your project here-->  
 <?php include 'includes/navbar.php'; ?>



 
  <!-- Section: Block Content -->
<?php include 'wpshare.php';?>

</div>
  <!-- jQuery -->
<?php include 'includes/footer.php'; ?>  
<?php include 'includes/jslinks.php'; ?>
<!-- all modals -->
<!-- Button trigger modal -->

</body>
</html>
